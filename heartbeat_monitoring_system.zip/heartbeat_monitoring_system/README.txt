HEARTBEAT MONITORING SYSTEM - PHP / MYSQL WEBSITE

FILES
- index.php       Redirects user to login or dashboard
- dashboard.php   Displays latest BPM, Wi-Fi status and GSM call status
- footer.php      Shared footer
- header.php      Shared page header/navigation
- reader.php      GET latest reading; POST a reading from ESP32
- register.php    Creates a user account
- login.php       User login
- logout.php      Ends the session
- db.php          Database connection
- style.css       Website design
- schema.sql      Database and tables

INSTALLATION WITH XAMPP
1. Copy the heartbeat_monitoring_system folder into:
   C:\xampp\htdocs\
2. Open XAMPP Control Panel and start Apache and MySQL.
3. Open http://localhost/phpmyadmin
4. Choose Import, select schema.sql from this folder, then click Import/Go.
5. Open http://localhost/heartbeat_monitoring_system/
6. Register a user, then login to the dashboard.

ESP32 READER API
The ESP32 must send an HTTP POST request to:
http://YOUR_COMPUTER_IP/heartbeat_monitoring_system/reader.php

Send JSON such as:
{
  "bpm": 72,
  "wifi_status": "Connected",
  "call_status": "No emergency call"
}

Add this HTTP header:
Content-Type: application/json
X-API-Key: CHANGE_THIS_TO_A_LONG_RANDOM_SECRET

IMPORTANT:
- In reader.php, replace the API key with a long private random key.
- Use exactly the same key in your ESP32 sketch.
- The phone/computer and ESP32 should be on the same Wi-Fi network.
- Use your computer's LAN IP address instead of localhost in the ESP32 URL.
- This PHP website receives and displays readings; it does not itself measure pulse or place GSM calls. Those functions are performed by the ESP32 and connected hardware.
- Configure HTTPS and stronger deployment security before exposing this site to the public internet.
- Educational prototype only; not a medical device.
