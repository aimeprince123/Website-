<?php
require_once "db.php";
header("Content-Type: application/json; charset=utf-8");

$API_KEY = "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $receivedKey = $_SERVER["HTTP_X_API_KEY"] ?? "";
    if (!hash_equals($API_KEY, $receivedKey)) {
        http_response_code(401);
        echo json_encode(["success" => false, "message" => "Unauthorized"]);
        exit;
    }

    $input = json_decode(file_get_contents("php://input"), true);
    if (!is_array($input)) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "Invalid JSON"]);
        exit;
    }

    $bpm = filter_var($input["bpm"] ?? null, FILTER_VALIDATE_FLOAT);
    if ($bpm === false || $bpm === null || $bpm < 0 || $bpm > 300) {
        http_response_code(422);
        echo json_encode(["success" => false, "message" => "BPM must be between 0 and 300"]);
        exit;
    }

    $wifi = substr(trim((string)($input["wifi_status"] ?? "Connected")), 0, 30);
    $call = substr(trim((string)($input["call_status"] ?? "No emergency call")), 0, 100);

    $stmt = $pdo->prepare(
        "INSERT INTO heartbeat_readings (bpm, wifi_status, call_status) VALUES (?, ?, ?)"
    );
    $stmt->execute([$bpm, $wifi, $call]);

    echo json_encode(["success" => true, "message" => "Reading saved"]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $stmt = $pdo->query(
        "SELECT bpm, wifi_status, call_status, created_at
         FROM heartbeat_readings ORDER BY id DESC LIMIT 1"
    );
    $reading = $stmt->fetch();

    echo json_encode([
        "success" => true,
        "reading" => $reading ?: null
    ]);
    exit;
}

http_response_code(405);
echo json_encode(["success" => false, "message" => "Method not allowed"]);
?>