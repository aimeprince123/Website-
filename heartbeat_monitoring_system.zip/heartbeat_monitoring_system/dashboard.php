<?php
session_start();
if (empty($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}
require_once "db.php";

$stmt = $pdo->query("SELECT COUNT(*) FROM heartbeat_readings");
$totalReadings = (int)$stmt->fetchColumn();
$stmt = $pdo->query("SELECT bpm, wifi_status, call_status, created_at FROM heartbeat_readings ORDER BY id DESC LIMIT 1");
$latest = $stmt->fetch();

require "header.php";
?>
<div class="dashboard-heading">
    <div>
        <p class="eyebrow">HEARTBEAT MONITORING</p>
        <h1>Dashboard</h1>
        <p class="muted">Welcome, <?= htmlspecialchars($_SESSION["full_name"] ?? "User") ?>. Here is your system overview.</p>
    </div>
    <div class="live-pill"><span class="live-dot"></span> Dashboard active</div>
</div>

<section class="stat-grid">
    <article class="stat-card bpm-card">
        <div class="stat-top"><span>Current heartbeat</span><span class="stat-icon">♥</span></div>
        <div class="stat-value"><span id="bpm"><?= $latest ? htmlspecialchars($latest["bpm"]) : "--" ?></span> <small>BPM</small></div>
        <p id="reading-time" class="stat-note"><?= $latest ? "Last update: " . htmlspecialchars($latest["created_at"]) : "Waiting for ESP32 reading" ?></p>
    </article>
    <article class="stat-card">
        <div class="stat-top"><span>Wi-Fi connection</span><span class="stat-icon blue">⌁</span></div>
        <div class="status-value" id="wifi-status"><?= $latest ? htmlspecialchars($latest["wifi_status"]) : "Waiting" ?></div>
        <p class="stat-note">ESP32 network status</p>
    </article>
    <article class="stat-card">
        <div class="stat-top"><span>GSM call status</span><span class="stat-icon orange">☎</span></div>
        <div class="status-value" id="call-status"><?= $latest ? htmlspecialchars($latest["call_status"]) : "No data" ?></div>
        <p class="stat-note">Emergency call information</p>
    </article>
    <article class="stat-card">
        <div class="stat-top"><span>Total readings</span><span class="stat-icon green">▤</span></div>
        <div class="stat-value" id="total-readings"><?= $totalReadings ?></div>
        <p class="stat-note">Readings saved in database</p>
    </article>
</section>

<section class="content-grid">
    <article class="panel">
        <div class="panel-heading">
            <div><h2>Live heartbeat</h2><p class="muted">Latest BPM received from the ESP32</p></div>
            <span class="live-pill"><span class="live-dot"></span> Live updates</span>
        </div>
        <div class="heart-display">
            <div class="pulse-heart">♥</div>
            <div><strong id="large-bpm"><?= $latest ? htmlspecialchars($latest["bpm"]) : "--" ?></strong><span>BPM</span></div>
        </div>
        <p class="center muted" id="connection-message">The page checks for new readings every 3 seconds.</p>
    </article>
    <article class="panel system-panel">
        <h2>System information</h2>
        <div class="info-row"><span>Controller</span><strong>ESP32-WROOM-32</strong></div>
        <div class="info-row"><span>Pulse sensor</span><strong>Analog sensor / compatible</strong></div>
        <div class="info-row"><span>Dashboard</span><strong>Wi-Fi web page</strong></div>
        <div class="info-row"><span>Alert method</span><strong>GSM emergency call</strong></div>
        <div class="info-row"><span>Last received</span><strong id="last-received"><?= $latest ? htmlspecialchars($latest["created_at"]) : "Not yet received" ?></strong></div>
    </article>
</section>

<div class="notice">
    <strong>Important safety note</strong>
    <p>This is an educational prototype, not a medical device. Do not use it to make medical decisions or as the only emergency alert system. A programmed BPM threshold is not a clinically validated emergency rule.</p>
</div>

<script>
async function updateDashboard() {
    try {
        const response = await fetch("reader.php", {cache: "no-store"});
        const data = await response.json();
        if (!data.success) throw new Error("Could not read data");

        if (data.reading) {
            const r = data.reading;
            document.getElementById("bpm").textContent = r.bpm;
            document.getElementById("large-bpm").textContent = r.bpm;
            document.getElementById("wifi-status").textContent = r.wifi_status;
            document.getElementById("call-status").textContent = r.call_status;
            document.getElementById("reading-time").textContent = "Last update: " + r.created_at;
            document.getElementById("last-received").textContent = r.created_at;
            document.getElementById("connection-message").textContent = "Latest reading received successfully.";
        } else {
            document.getElementById("connection-message").textContent = "No readings yet. Connect your ESP32 to begin.";
        }
    } catch (error) {
        document.getElementById("connection-message").textContent = "Unable to contact the server. Check your connection.";
    }
}
updateDashboard();
setInterval(updateDashboard, 3000);
</script>
<?php require "footer.php"; ?>