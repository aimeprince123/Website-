<?php
require_once "db.php";
session_start();

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = strtolower(trim($_POST["email"] ?? ""));
    $password = $_POST["password"] ?? "";

    $stmt = $pdo->prepare("SELECT id, full_name, password FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user["password"])) {
        session_regenerate_id(true);
        $_SESSION["user_id"] = (int)$user["id"];
        $_SESSION["full_name"] = $user["full_name"];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Incorrect email or password.";
    }
}
require "header.php";
?>
<section class="auth-card">
    <div class="auth-symbol">♥</div>
    <h1>Welcome back</h1>
    <p class="muted">Login to monitor your heartbeat system.</p>
    <?php if ($error): ?><div class="alert error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST">
        <label>Email address</label>
        <input type="email" name="email" required placeholder="Enter your email">
        <label>Password</label>
        <input type="password" name="password" required placeholder="Enter your password">
        <button type="submit" class="btn primary full">Login</button>
    </form>
    <p class="auth-bottom">Don't have an account? <a href="register.php">Register here</a></p>
</section>
<?php require "footer.php"; ?>