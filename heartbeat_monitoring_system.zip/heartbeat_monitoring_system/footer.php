</main>
<footer class="footer">
    <p>IoT-Based Heartbeat Monitoring System with GSM Emergency Call</p>
    <small>Educational prototype only — not a medical device.</small>
</footer>
</body>
</html>
