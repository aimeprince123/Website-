<?php
require_once "db.php";
session_start();

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["full_name"] ?? "");
    $email = strtolower(trim($_POST["email"] ?? ""));
    $password = $_POST["password"] ?? "";
    $confirm = $_POST["confirm_password"] ?? "";

    if ($name === "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Enter your full name and a valid email address.";
    } elseif (strlen($password) < 8) {
        $error = "Password must contain at least 8 characters.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        try {
            $stmt = $pdo->prepare(
                "INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)"
            );
            $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
            $_SESSION["user_id"] = (int)$pdo->lastInsertId();
            $_SESSION["full_name"] = $name;
            session_regenerate_id(true);
            header("Location: dashboard.php");
            exit;
        } catch (PDOException $e) {
            $error = "This email may already be registered. Try logging in.";
        }
    }
}
require "header.php";
?>
<section class="auth-card">
    <div class="auth-symbol">♥</div>
    <h1>Create an account</h1>
    <p class="muted">Register to access your heartbeat dashboard.</p>
    <?php if ($error): ?><div class="alert error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST">
        <label>Full name</label>
        <input type="text" name="full_name" required maxlength="100" placeholder="Enter your name">
        <label>Email address</label>
        <input type="email" name="email" required placeholder="example@email.com">
        <label>Password</label>
        <input type="password" name="password" required minlength="8" placeholder="At least 8 characters">
        <label>Confirm password</label>
        <input type="password" name="confirm_password" required minlength="8" placeholder="Repeat password">
        <button type="submit" class="btn primary full">Create account</button>
    </form>
    <p class="auth-bottom">Already registered? <a href="login.php">Login here</a></p>
</section>
<?php require "footer.php"; ?>