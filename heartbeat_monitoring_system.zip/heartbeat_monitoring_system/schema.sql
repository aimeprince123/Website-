CREATE DATABASE IF NOT EXISTS heartbeat_db
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE heartbeat_db;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS heartbeat_readings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    bpm DECIMAL(6,2) NOT NULL,
    wifi_status VARCHAR(30) DEFAULT 'Connected',
    call_status VARCHAR(100) DEFAULT 'No emergency call',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (created_at)
);

-- Change this key in reader.php and in your ESP32 sketch before deployment.
-- The API key is configured in reader.php for this beginner project.
